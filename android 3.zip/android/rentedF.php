<?php
// Include database connection
include 'db_connection.php';

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get the filter option from the query string
    $filter = isset($_GET['filter']) ? $_GET['filter'] : '';

    // Prepare SQL statement based on the filter option
    switch ($filter) {
        case 'rented_this_day':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 AND DATE(date_rental) = CURDATE()";
            break;
        case 'this_week':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 AND YEARWEEK(date_rental) = YEARWEEK(NOW())";
            break;
        case 'most_rented':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 ORDER BY number_of_rentals DESC LIMIT 1";
            break;
        case 'max_day_rented':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 ORDER BY DATEDIFF(drop_date, date_rental) DESC LIMIT 1";
            break;
        case 'max_price':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 ORDER BY offered_price DESC LIMIT 1";
            break;
        case 'least_price':
            $sql = "SELECT * FROM cars WHERE is_rented = 1 ORDER BY offered_price ASC LIMIT 1";
            break;
        default:
            // Default case: fetch all rented cars
            $sql = "SELECT * FROM cars WHERE is_rented = 1";
            break;
    }

    // Execute SQL query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Array to hold the rented cars
        $rentedCars = array();

        // Fetch rows and store them in the array
        while ($row = $result->fetch_assoc()) {
            $rentedCars[] = $row;
        }

        // Send JSON response back to the Android app
        echo json_encode(array("success" => true, "rentedCars" => $rentedCars));
    } else {
        // No rented cars found
        echo json_encode(array("success" => false, "message" => "No rented cars found."));
    }
} else {
    // Invalid request method
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}

// Close database connection
$conn->close();
?>
