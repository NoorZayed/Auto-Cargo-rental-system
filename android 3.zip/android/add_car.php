<?php
include 'db_connection.php';

$brand = $_POST['brand'];
$location = $_POST['location'];
$year_model = $_POST['year_model'];
$seats_number = $_POST['seats_number'];
$transmission = $_POST['transmission'];
$motor_fuel = $_POST['motor_fuel'];
$offered_price = $_POST['offered_price'];
$image = $_POST['image'];

$image = base64_decode($image);
$image_path = 'images/' . uniqid() . '.jpg';
file_put_contents($image_path, $image);
$image_url = 'http://192.168.1.104/android/' . $image_path;

$sql = "INSERT INTO cars (brand, location, year_model, seats_number, transmission, motor_fuel, offered_price, image)
VALUES ('$brand', '$location', '$year_model', '$seats_number', '$transmission', '$motor_fuel', '$offered_price', '$image_url')";

if ($conn->query($sql) === TRUE) {
    echo "New car added successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
