<?php
include 'db_connection.php';

// Check if the location is provided in the request
if(isset($_GET['location']) && !empty($_GET['location'])) {
    // Modify the SQL query to fetch only the cars that are not rented and match the provided location
    $location = $_GET['location'];
    $sql = "SELECT * FROM cars WHERE is_rented = 0 AND location = '$location'";
} else {
    // Modify the SQL query to fetch only the cars that are not rented
    $sql = "SELECT * FROM cars WHERE is_rented = 0";
}

$result = $conn->query($sql);

$response = array();
if ($result->num_rows > 0) {
    $response['success'] = true;
    $cars = array();
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
    $response['cars'] = $cars;
} else {
    $response['success'] = false;
    $response['message'] = "No cars found";
}

echo json_encode($response);
$conn->close();
?>
