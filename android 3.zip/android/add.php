<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'db_connection.php';


$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $brand = $_POST['brand'];
    $location = $_POST['location'];
    $yearModel = $_POST['yearModel'];
    $seatsNumber = $_POST['seatsNumber'];
    $transmission = $_POST['transmission'];
    $motorFuel = $_POST['motorFuel'];
    $offeredPrice = $_POST['offeredPrice'];

    if (empty($brand) || empty($location) || empty($yearModel) || empty($seatsNumber) || empty($transmission) || empty($motorFuel) || empty($offeredPrice)) {
        $response['message'] = "Please fill in all required fields.";
    } else {
        $target_dir = "test/";
        $target_file = $target_dir . basename($_FILES["image"]["name"]);

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $query = "INSERT INTO cars (brand, location, year_model, seats_number, transmission, motor_fuel, offered_price, image) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sssissds", $brand, $location, $yearModel, $seatsNumber, $transmission, $motorFuel, $offeredPrice, $target_file);
                if ($stmt->execute()) {
                    $response['success'] = true;
                    $response['message'] = "Car added successfully.";
                } else {
                    $response['success'] = false;
                    $response['message'] = "Error adding car.";
                }
                $stmt->close();
            } else {
                $response['success'] = false;
                $response['message'] = "Sorry, there was an error uploading your file.";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "File is not an image.";
        }
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}
header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
