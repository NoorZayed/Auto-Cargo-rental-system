<?php
include 'db_connection.php';

// Function to fetch data based on filter
function fetchData($filter) {
    global $conn;

    // Define the query based on filter
    $query = "";
    switch ($filter) {
        case "most_rented_car":
            $query = "SELECT brand, `number of rentals` AS count FROM cars GROUP BY brand ORDER BY count DESC LIMIT 1";
            break;
        case "most_rated_car":
            $query = "SELECT brand, AVG(rating) AS count FROM cars GROUP BY brand ORDER BY count DESC LIMIT 1";
            break;
        case "most_price_car":
            $query = "SELECT brand, MAX(offered_price) AS count FROM cars LIMIT 1";
            break;
        default:
            $response['success'] = false;
            $response['message'] = "Invalid filter";
            echo json_encode($response);
            return;
    }

    // Execute the query
    $result = $conn->query($query);

    $response = array();
    if ($result->num_rows > 0) {
        // Fetch data
        $row = $result->fetch_assoc();
        $response = $row; // Just set the row directly to the response
    } else {
        // Return empty JSON response if no data found
        $response['success'] = false;
        $response['message'] = "No data found";
    }

    // Return JSON response
    echo json_encode($response);
}

// Check if 'filter' parameter is set in the URL
if (isset($_GET['filter'])) {
    // Fetch data based on filter
    fetchData($_GET['filter']);
} else {
    // If 'filter' parameter is not provided, return empty JSON response
    $response['success'] = false;
    $response['message'] = "Filter parameter not provided";
    echo json_encode($response);
}

$conn->close();
?>
