<?php
include 'db_connection.php';

if(isset($_POST['car_id'], $_POST['brand'], $_POST['location'], $_POST['year_model'], $_POST['seats_number'], $_POST['transmission'], $_POST['motor_fuel'], $_POST['offered_price'])) {

    $car_id = mysqli_real_escape_string($conn, $_POST['car_id']);
    $brand = mysqli_real_escape_string($conn, $_POST['brand']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $year_model = mysqli_real_escape_string($conn, $_POST['year_model']);
    $seats_number = mysqli_real_escape_string($conn, $_POST['seats_number']);
    $transmission = mysqli_real_escape_string($conn, $_POST['transmission']);
    $motor_fuel = mysqli_real_escape_string($conn, $_POST['motor_fuel']);
    $offered_price = mysqli_real_escape_string($conn, $_POST['offered_price']);

    if(is_numeric($year_model) && is_numeric($seats_number) && is_numeric($offered_price) && is_numeric($car_id)) {

        $sql = "UPDATE cars SET brand=?, location=?, year_model=?, seats_number=?, transmission=?, motor_fuel=?, offered_price=? WHERE id=?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssissii", $brand, $location, $year_model, $seats_number, $transmission, $motor_fuel, $offered_price, $car_id);

        if ($stmt->execute()) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error: Invalid input";
    }
} else {
    echo "Error: Missing required fields";
}

$conn->close();
?>
