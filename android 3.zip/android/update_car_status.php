<?php
include 'db_connection.php';

function setRented($carId, $rented, $dateRental, $dropDate) {
    global $conn;
    
    // Input validation
    if (!is_numeric($carId) || !is_numeric($rented) || !strtotime($dateRental) || !strtotime($dropDate)) {
        return false;
    }

    $carId = intval($carId);
    $rented = intval($rented);
    $dateRental = date('Y-m-d', strtotime($dateRental));
    $dropDate = date('Y-m-d', strtotime($dropDate));
    
    try {
        // Prepare the SQL statement
        $stmt = $conn->prepare("UPDATE cars SET is_rented = ?, date_rental = ?, drop_date = ? WHERE id = ?");
        // Bind parameters
        $stmt->bind_param("issi", $rented, $dateRental, $dropDate, $carId);
        // Execute the statement
        $stmt->execute();
        
        // Check if the update was successful
        if ($stmt->affected_rows > 0) {
            return true; // Update successful
        } else {
            return false; // Update failed
        }
    } catch (Exception $e) {
        // Handle database errors
        error_log($e->getMessage()); // Log the error message for debugging
        return false;
    }
}

// Check if the required parameters are set in the URL
if (isset($_GET['id']) && isset($_GET['rented']) && isset($_GET['date_rental']) && isset($_GET['drop_date'])) {
    // Get the parameters from the URL
    $carId = $_GET['id'];
    $rented = $_GET['rented'];
    $dateRental = $_GET['date_rental'];
    $dropDate = $_GET['drop_date'];
    
    // Perform the database operation
    if (setRented($carId, $rented, $dateRental, $dropDate)) {
        echo json_encode(array("success" => true, "message" => "Rented status and dates updated successfully"));
    } else {
        echo json_encode(array("success" => false, "message" => "Failed to update rented status and dates"));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Invalid parameters"));
}

$conn->close();
?>
