<?php
include 'db_connection.php';

$query = "SELECT car_id, COUNT(*) AS rental_count FROM rentals GROUP BY car_id ORDER BY rental_count DESC LIMIT 1";
$result = mysqli_query($conn, $query);

$response = array();

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response['car_id'] = $row['car_id'];
    $response['rental_count'] = $row['rental_count'];
}

echo json_encode($response);
$conn->close();
?>
