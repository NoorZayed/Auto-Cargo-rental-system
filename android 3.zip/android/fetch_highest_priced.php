<?php
include 'db_connection.php';

$query = "SELECT * FROM cars ORDER BY offered_price DESC LIMIT 1";
$result = mysqli_query($conn, $query);

$response = array();

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response['car_id'] = $row['id'];
    $response['brand'] = $row['brand'];
    $response['location'] = $row['location'];
    $response['year_model'] = $row['year_model'];
    $response['seats_number'] = $row['seats_number'];
    $response['transmission'] = $row['transmission'];
    $response['motor_fuel'] = $row['motor_fuel'];
    $response['offered_price'] = $row['offered_price'];
    $response['image'] = $row['image'];
}

echo json_encode($response);
$conn->close();
?>
