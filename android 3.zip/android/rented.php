<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection
include 'db_connection.php';

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Prepare SQL statement to select rented cars
    $sql = "SELECT id,brand,location,year_model,seats_number,transmission,motor_fuel,offered_price,rating, 
            DATE_FORMAT(date_rental, '%Y-%m-%d') AS date_rental, 
            DATE_FORMAT(drop_date, '%Y-%m-%d') AS drop_date, 
            image 
            FROM cars 
            WHERE is_rented = 1";

    // Execute SQL query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Array to hold the rented cars
        $rentedCars = array();

        // Fetch rows and store them in the array
        while ($row = $result->fetch_assoc()) {
            $rentedCars[] = $row;
        }

        // Send JSON response back to the Android app
        echo json_encode(array("success" => true, "rentedCars" => $rentedCars));
    } else {
        // No rented cars found
        echo json_encode(array("success" => false, "message" => "No rented cars found."));
    }
} else {
    // Invalid request method
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}

// Close database connection
$conn->close();
?>
