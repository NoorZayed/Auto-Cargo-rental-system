<?php
include 'db_connection.php';

// Query to get the most rated car
$query = "SELECT car_id, AVG(rating) AS avg_rating FROM ratings GROUP BY car_id ORDER BY avg_rating DESC LIMIT 1";
$result = mysqli_query($conn, $query);

$response = array();

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response['car_id'] = $row['car_id'];
    $response['avg_rating'] = $row['avg_rating'];
}

echo json_encode($response);
$conn->close();
?>
