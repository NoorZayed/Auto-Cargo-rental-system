<?php
// Include database connection
include 'db_connection.php';

// Check if it's a GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Prepare SQL statement to select rented cars
    $sql = "SELECT * FROM cars WHERE is_rented = 1";

    // Execute SQL query
    $result = $conn->query($sql);

    // Check if there are any results
    if ($result->num_rows > 0) {
        // Array to hold the rented cars
        $rentedCars = array();

        // Fetch rows and store them in the array
        while($row = $result->fetch_assoc()) {
            $rentedCars[] = $row;
        }

        // Send JSON response back to the Android app
        echo json_encode(array("success" => true, "rentedCars" => $rentedCars));
    } else {
        // No rented cars found
        echo json_encode(array("success" => false, "message" => "No rented cars found."));
    }
} else {
    // Invalid request method
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}

// Close database connection
$conn->close();
?>
