<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['car_id'])) {
        $car_id = $_POST['car_id'];

        $sql = "DELETE FROM cars WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $car_id);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = "Car deleted successfully";
        } else {
            $response['success'] = false;
            $response['message'] = "Error deleting car";
        }
        $stmt->close();
    } else {
        $response['success'] = false;
        $response['message'] = "Car ID not provided";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method";
}

echo json_encode($response);
$conn->close();
?>
