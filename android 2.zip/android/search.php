<?php
include 'db_connection.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['searchQuery']) && isset($_GET['filter'])) {
        $searchQuery = mysqli_real_escape_string($conn, $_GET['searchQuery']);
        $filter = mysqli_real_escape_string($conn, $_GET['filter']);

        // Build the SQL query based on the filter
        switch ($filter) {
            case 'brand':
            case 'location':
            case 'year_model':
            case 'seats_number':
            case 'transmission':
            case 'motor_fuel':
            case 'offered_price':
                $sql = "SELECT * FROM cars WHERE $filter LIKE '%$searchQuery%'";
                break;
            default:
                echo json_encode(array("success" => false, "message" => "Invalid filter parameter."));
                $conn->close();
                exit();
        }

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $searchResults = array();

            while ($row = $result->fetch_assoc()) {
                $searchResults[] = $row;
            }

            echo json_encode(array("success" => true, "cars" => $searchResults));
        } else {
            echo json_encode(array("success" => false, "message" => "No cars found."));
        }
    } else {
        echo json_encode(array("success" => false, "message" => "Search query or filter parameter is not set."));
    }
} else {
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}

$conn->close();
?>
