<?php
include 'db_connection.php';

// Check if car_id is present
if(isset($_GET['car_id'])) {
    $car_id = mysqli_real_escape_string($conn, $_GET['car_id']);

    // Prepare the SQL statement to fetch car details
    $sql = "SELECT brand, location, year_model, seats_number, transmission, motor_fuel, offered_price FROM cars WHERE id=?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $stmt->bind_result($brand, $location, $year_model, $seats_number, $transmission, $motor_fuel, $offered_price);

    // Fetch the result
    if ($stmt->fetch()) {
        $car = array(
            "brand" => $brand,
            "location" => $location,
            "year_model" => $year_model,
            "seats_number" => $seats_number,
            "transmission" => $transmission,
            "motor_fuel" => $motor_fuel,
            "offered_price" => $offered_price
        );
        echo json_encode($car);
    } else {
        echo "Error: Car not found";
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Error: Missing car_id";
}

// Close the connection
$conn->close();
?>
