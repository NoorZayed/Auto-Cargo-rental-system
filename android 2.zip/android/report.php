<?php
include 'db_connection.php';

$sql = "SELECT * FROM cars";

$result = $conn->query($sql);

$response = array();
if ($result->num_rows > 0) {
    $response['success'] = true;
    $cars = array();
    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
    $response['cars'] = $cars;
} else {
    $response['success'] = false;
    $response['message'] = "No cars found";
}

echo json_encode($response);
$conn->close();
?>